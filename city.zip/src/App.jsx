import Scene from "./components/scene";

function App() {
  return <Scene />;
}

export default App;
