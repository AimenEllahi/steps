import Scene from "./components/scene";
import Sidebar from "./components/Sidebar";

function App() {
  return (
    <div className="overflow-hidden">
      <Scene />
    </div>
  );
}

export default App;
